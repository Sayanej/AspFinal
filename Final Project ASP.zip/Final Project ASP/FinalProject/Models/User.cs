﻿namespace FinalProject.Models
{
    public class User
    {
        public int UserId { get; set; }

        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int UserAge { get; set; }
        public int UserPhone { get; set; }
        public string UserEmail { get; set; }

        public List<Quote>? Quotes { get; set; }
    }
}
