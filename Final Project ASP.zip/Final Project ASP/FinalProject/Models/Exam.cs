﻿using Microsoft.Build.Framework;
using System.ComponentModel.DataAnnotations;

namespace FinalProject.Models
{
    public class Exam
    {
        [Required(), MaxLength(11)]
        public int Id { get; set; }

        [Required]
        public int RoleId { get; set; }

        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }



    }
}
