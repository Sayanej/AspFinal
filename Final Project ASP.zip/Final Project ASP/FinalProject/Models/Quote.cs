﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;
using System;

namespace FinalProject.Models
{
    public class Quote
    {
        public int QuoteId { get; set; }

        public int PersonID { get; set; }

        [Required]
        [Range(minimum: 0.01, maximum: 99999999)]
        [DisplayFormat(DataFormatString = "{0:c}")]  //MS currency format
        [Display(Name = "Value of the car:")]
        public decimal ItemValue { get; set; }

        [Required]
        [Range(minimum: 0, maximum: 40)]
        [Display(Name = "Owned time:")]
        public int OwnedTime { get; set; }

        [Required]
        [Range(minimum: 0, maximum: 6)]
        [Display(Name = "No. of Claims:")]
        public int ClaimNumber { get; set; }
        //a variable to control access

        private double _quotePrice;

        [DisplayFormat(DataFormatString = "{0:c}")]  //MS currency format
        /*A really simple formula to calculate the insurance, as actually calculating the insurance depends on multiple factors*/
        public double QuotePrice
        {
            get
            {
                if (ClaimNumber < 1)
                {
                    _quotePrice = (double)((ItemValue/3) / OwnedTime);
                }
                else if (ClaimNumber > 1)
                {
                    _quotePrice = (double)((ItemValue - OwnedTime) / ClaimNumber);
                }
                return _quotePrice;
            }
            set
            {
                _quotePrice = value;
            }
        }

        public User? User { get; set; }


    }
}
