﻿using System.ComponentModel.DataAnnotations;

namespace FinalProject.Models
{
    public class CarMake
    {
        public int CarMakeId { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "You must enter a make name!")]

        public string MakeName { get; set; }

        public List<Car>? Cars { get; set; }  //? denotes that it can be null
    }
}
