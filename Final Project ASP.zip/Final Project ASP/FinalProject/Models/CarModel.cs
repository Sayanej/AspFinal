﻿using System.ComponentModel.DataAnnotations;

namespace FinalProject.Models
{
    public class CarModel
    {
        //primary key of CarModel
        public int CarModelId { get; set; }
        //primary key for make
        public int CarMakeId { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "You must enter a model name!")]

        public string ModelName { get; set; }

        //reference to the carmake parent class
        //? at the end of carmake means it can be null
        public CarMake? Make { get; set; }

        //referrence to the car child class
        public List<Car>? Cars { get; set; }  //? denotes that it can be null

    }
}
