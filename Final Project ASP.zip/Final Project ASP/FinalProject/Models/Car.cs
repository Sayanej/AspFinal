﻿using System.ComponentModel.DataAnnotations;

namespace FinalProject.Models
{
    public class Car
    {
        public int CarId { get; set; }

        [Required]
        public int Year { get; set; }

        public int? MakeCarMakeId { get; set; } // Foreign key property
        public CarMake? Make { get; set; } // Navigation property

        public int? ModelCarModelId { get; set; } // Foreign key property
        public CarModel? Model { get; set; } // Navigation property
    }
}
