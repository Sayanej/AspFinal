﻿using FinalProject.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;

namespace FinalProject.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
            public DbSet<Car> Cars { get; set; }
            public DbSet<CarMake> CarMakes { get; set; }

            public DbSet<CarModel> CarModels { get; set; }

            public DbSet<User> Users { get; set; }

            public DbSet<Quote> Quotes { get; set; }
            public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
    }
}